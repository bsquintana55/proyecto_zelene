function Evento_R(){
    let evento = document.getElementById('evento').value;
    let fechaI = document.getElementById('fechaI').value;
    let fechaF = document.getElementById('fechaF').value;
    let descrip = document.getElementById('descripcion').value;
  
    
    
    if (evento === "" || fechaI === "" || fechaF === "" || descrip === "") {
        Swal.fire({icon: 'error',
                  title: 'Todos los campos son necesarios, digitelos.'});
        return false;
    }
    
    else if(evento.length<2){
        Swal.fire({icon: 'error',
                  title: 'El nombre esta corto',
                  text: 'Recuerde ingresarlos correctamente'});
        return false;
    }
    else if(descrip.length<5){
        Swal.fire({icon: 'error',
                  title: 'La descripcion esta corta',
                  text: 'Recuerde ingresarlos correctamente'});
        return false;
    }
    
    else if(evento.length>11){
         Swal.fire({icon: 'error',
                  title: 'El nombre esta muy largo',
                  text: 'Por favor digite hasta 11 caracteres'});
         return false;
    }
    
   

    
    
}
