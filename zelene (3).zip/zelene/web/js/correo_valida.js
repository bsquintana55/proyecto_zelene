/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */




function correo(){
    let correo = document.getElementById('correo').value;
      
   expresion =/^[a-zA-Z0-9_.+-]+@+[gmail]+.[c]+[o]+[m]$/;
    
  
    if (!expresion.test(correo)){
        Swal.fire({icon: 'error',
                  title: 'La dirección del correo no es valida ',
                  text: 'Recuerde que debe ser con el dominio gmail'});
        return false;
 

}


}
