/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function participante(){
    let nombre = document.getElementById('nombre').value;
    let correo = document.getElementById('correo').value;
    let celular = document.getElementById('celular').value;
  
    
    
    if (nombre === "" || correo === "" || celular === "" ) {
        Swal.fire({icon: 'error',
                  title: 'Todos los campos son necesarios, digitelos.'});
        return false;
    }
    
    else if(nombre.length<1){
        Swal.fire({icon: 'error',
                  title: 'El nombre esta corto',
                  text: 'Recuerde ingresarlos correctamente'});
        return false;
    }
     else if(nombre.length>11){
         Swal.fire({icon: 'error',
                  title: 'El nombre esta muy largo',
                  text: 'Por favor digite hasta 11 caracteres'});
         return false;
    }
    else if(celular.length<5){
        Swal.fire({icon: 'error',
                  title: ' El numero celular no es valido'});
        return false;
    }
    else if(celular.length>10){
        Swal.fire({icon: 'error',
                  title: ' El numero es demaciado largo.'});
        return false;
    }
  
}
