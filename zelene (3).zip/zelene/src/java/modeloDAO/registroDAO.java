/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloDAO;

import Util.ConexionBd;
import Util.Crud;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import modeloVO.eventoVO;
import modeloVO.partiVO;
import modeloVO.registroVO;

/**
 *
 * @author Sena
 */
public class registroDAO extends ConexionBd implements Crud {
     //1. Declarar variables 
    private Connection conexion;
    private PreparedStatement puente;
    private ResultSet mensajero;

    private boolean operacion = false;
    private String sql;
    
    private String id_reg="", 
                   id_even="", 
                   id_parti="",
                   fecha_reg="",
            //para que retorne
                   r ="";
    
    
    
    
    
     //metodo para recibir datos del vo
    public registroDAO(registroVO regVO) {
        super();

        try {
            //conectarse
            conexion = this.obtenerConexion();

            //taer datos
            id_reg = regVO.getId_reg();
            id_even= regVO.getId_even();
            id_parti = regVO.getId_parti();
            fecha_reg= regVO.getFecha_reg();
            

        } catch (Exception e) {
            Logger.getLogger(registroDAO.class.getName()).log(Level.SEVERE, null, e);
        }

    }

   
       //se le da a un obj los metodos correspondientes
  // private ArrayList<eventoVO> listarEventos = list();
    
 //  private partiVO traeParti = consultarParti();
    
    
   

        
   public ArrayList <eventoVO>list()
    {
        ArrayList<eventoVO>listEven = new ArrayList<>(); 
        
        try 
        {
            conexion = this.obtenerConexion();
           
           sql = "SELECT evento.id_even, evento.nombre_even from evento WHERE estado_even= 'I'";
           puente = conexion.prepareStatement(sql);
           mensajero = puente.executeQuery();
           while(mensajero.next())
           {
               eventoVO eveVO = new eventoVO(
                    mensajero.getString(1),
                    mensajero.getString(2)

               );
               listEven.add(eveVO);
           }
           
                        
        } catch (SQLException e) 
        {
            Logger.getLogger(eventoDAO.class.getName()).log(Level.SEVERE, null, e);
        }
        finally
        {
            try 
            {
                this.cerrarConexion();
            } catch (SQLException e) 
            {
                Logger.getLogger(eventoDAO.class.getName()).log(Level.SEVERE, null, e);
            }
        }
        return listEven;
        
        
      
    }
   
    
        
    
    
    //consulta de taer el id del participante
       public partiVO consultarParti() {
        partiVO partVO = null;
        try {
            conexion = this.obtenerConexion();
            sql = "SELECT participante.id_parti, participante.nombre_parti FROM participante WHERE participante.id_parti = ?;";
            puente = conexion.prepareStatement(sql);
            
                
            mensajero = puente.executeQuery();
            //utiliza el evento vo de sin el id obvi
            while (mensajero.next()) {
                partVO = new partiVO
                (
                  mensajero.getString(1),
                  mensajero.getString(2)
                );
            }
        } catch (SQLException e) {
            Logger.getLogger(eventoDAO.class.getName()).log(Level.SEVERE, null, e);
        } finally {
            try {
                this.cerrarConexion();
            } catch (SQLException e) {
                Logger.getLogger(eventoDAO.class.getName()).log(Level.SEVERE, null, e);
            }
        }
        return partVO;
    }
    
       
       
    ////////////////////////////////////////////////////////////////////////////////
        
    
    //registrar registro id even y id parti
       
       public String registro(registroVO regVO){
           
           try {
               conexion = this.obtenerConexion();
               sql="insert into registro (id_even, id_parti) values(?,?)";
               puente = conexion.prepareStatement(sql);
               puente.setString(1, regVO.getId_even());
               puente.setString(2, regVO.getId_parti());
               puente.executeUpdate();
              
           } catch (Exception e) {
            Logger.getLogger(eventoDAO.class.getName()).log(Level.SEVERE, null, e);
           }
           return r;
       }

   
   
   
    

    @Override
    public boolean agregarRegistro() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
     }

    @Override
    public boolean actualizarRegistro() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean eliminarRegistro() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
   
}
